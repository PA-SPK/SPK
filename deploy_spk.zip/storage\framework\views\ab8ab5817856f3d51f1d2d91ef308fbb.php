<?php $__env->startSection('title', 'Dashboard SPK - Sistem Pendukung Keputusan AHP & TOPSIS'); ?>
<?php $__env->startSection('page_title', 'Ringkasan Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-margin max-w-[1540px] mx-auto w-full flex flex-col gap-space-lg">
    <!-- Top Header Overview -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-space-md">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed font-label-sm text-label-sm font-semibold">
                    Sistem Pendukung Keputusan
                </span>
                <span class="text-on-surface-variant font-label-sm text-label-sm tracking-wide uppercase"><?php echo e($metrics['metode']); ?></span>
            </div>
            <h1 class="font-headline-xl text-headline-xl text-on-surface tracking-tight">Dashboard Perhitungan SPK</h1>
            <p class="font-body-md text-on-surface-variant mt-0.5">Pengambilan keputusan multi-kriteria menggunakan pembobotan AHP dan <?php echo e($metrics['metode_name']); ?>.</p>
        </div>
        <?php if(!$isEmpty): ?>
        <div class="flex flex-col sm:flex-row sm:items-center gap-space-sm self-start md:self-auto">
            <div class="flex items-center gap-space-xs px-3.5 py-2 rounded-xl bg-surface-container-lowest shadow-sm border border-outline-variant/20">
                <span class="material-symbols-outlined text-primary text-[18px]">verified</span>
                <span class="font-label-md text-label-md text-on-surface">Uji AHP: KONSISTEN (CR = <?php echo e(number_format($metrics['cr'], 4)); ?>)</span>
            </div>
            <div class="flex items-center gap-space-xs px-3.5 py-2 rounded-xl bg-surface-container-high text-on-surface-variant border border-outline-variant/10">
                <span class="material-symbols-outlined text-[18px] text-primary">analytics</span>
                <span class="font-label-md text-label-md"><?php echo e($metrics['total_alternatif']); ?> Alternatif</span>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <?php if($isEmpty): ?>
    <!-- Empty State Banner -->
    <div class="rounded-3xl bg-surface-container-lowest border-2 border-dashed border-outline-variant/40 p-10 md:p-16 flex flex-col items-center justify-center text-center gap-space-md">
        <div class="w-20 h-20 rounded-3xl bg-primary/10 flex items-center justify-center text-primary mb-2">
            <span class="material-symbols-outlined text-[42px]">upload_file</span>
        </div>
        <div>
            <h2 class="font-headline-lg text-headline-lg text-on-surface font-bold">Belum Ada Data SPK</h2>
            <p class="font-body-md text-on-surface-variant mt-2 max-w-lg mx-auto leading-relaxed">
                Aplikasi ini siap digunakan! Mulai dengan mengimpor data kriteria dan alternatif dari file Excel/CSV, 
                atau muat data demo untuk mencoba fitur perhitungan multi-metode SPK.
            </p>
        </div>
        <div class="flex flex-col sm:flex-row gap-space-sm mt-2">
            <a href="<?php echo e(route('spk.import')); ?>" class="flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-on-primary font-label-md text-sm hover:bg-primary/90 shadow-md shadow-primary/20 transition-all font-semibold">
                <span class="material-symbols-outlined text-[20px]">upload_file</span>
                <span>Import File Excel / CSV</span>
            </a>
            <a href="<?php echo e(route('spk.import.template')); ?>" class="flex items-center gap-2 px-6 py-3 rounded-xl bg-surface-container text-on-surface font-label-md text-sm hover:bg-surface-container-high border border-outline-variant/20 transition-all font-semibold">
                <span class="material-symbols-outlined text-[20px]">download</span>
                <span>Unduh Template</span>
            </a>
            <a href="<?php echo e(route('spk.settings')); ?>" class="flex items-center gap-2 px-6 py-3 rounded-xl bg-primary-fixed/30 text-primary font-label-md text-sm hover:bg-primary-fixed/50 transition-all font-semibold">
                <span class="material-symbols-outlined text-[20px]">local_hospital</span>
                <span>Muat Data Demo</span>
            </a>
        </div>
        <!-- Step Guide -->
        <div class="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-space-sm w-full max-w-2xl">
            <div class="flex flex-col items-center gap-2 p-4 rounded-2xl bg-surface-container-low">
                <div class="w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-sm">1</div>
                <span class="font-label-sm text-sm text-on-surface font-semibold">Import Data</span>
                <span class="font-body-sm text-xs text-on-surface-variant text-center">Upload Excel/CSV dengan kriteria dan alternatif</span>
            </div>
            <div class="flex flex-col items-center gap-2 p-4 rounded-2xl bg-surface-container-low">
                <div class="w-8 h-8 rounded-full bg-surface-container text-on-surface-variant flex items-center justify-center font-bold text-sm">2</div>
                <span class="font-label-sm text-sm text-on-surface font-semibold">Atur Bobot AHP</span>
                <span class="font-body-sm text-xs text-on-surface-variant text-center">Sesuaikan matriks perbandingan kriteria</span>
            </div>
            <div class="flex flex-col items-center gap-2 p-4 rounded-2xl bg-surface-container-low">
                <div class="w-8 h-8 rounded-full bg-surface-container text-on-surface-variant flex items-center justify-center font-bold text-sm">3</div>
                <span class="font-label-sm text-sm text-on-surface font-semibold">Lihat Keputusan</span>
                <span class="font-body-sm text-xs text-on-surface-variant text-center">Hasil perankingan <?php echo e($metrics['metode']); ?> tersedia otomatis</span>
            </div>
        </div>
    </div>
    <?php else: ?>

    <!-- Top KPI Grid: 5 Cards Deck -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-gutter items-stretch">
        <!-- Card 1: Featured Primary Hero Card -->
        <div class="lg:col-span-3 rounded-2xl bg-primary text-on-primary p-space-lg flex flex-col justify-between shadow-xl shadow-primary/20 relative overflow-hidden group">
            <div class="absolute -right-6 -bottom-6 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500"></div>
            <div class="flex items-start justify-between relative z-10">
                <div class="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-on-primary">
                    <span class="material-symbols-outlined text-[22px]">domain</span>
                </div>
                <span class="px-2.5 py-1 rounded-full bg-white/20 text-on-primary font-label-sm text-label-sm backdrop-blur-sm">
                    Status: Selesai
                </span>
            </div>
            <div class="mt-space-md relative z-10">
                <p class="font-label-sm text-label-sm text-primary-fixed tracking-wide uppercase">Total Alternatif</p>
                <div class="font-numeric-metric text-numeric-metric text-on-primary mt-0.5 tracking-tight flex items-baseline gap-1.5">
                    <span><?php echo e($metrics['total_alternatif']); ?></span>
                    <span class="font-headline-sm text-headline-sm font-medium text-white/90">Alternatif</span>
                </div>
                <p class="font-body-sm text-body-sm text-white/80 mt-1">Dievaluasi untuk rekomendasi terbaik</p>
            </div>
        </div>

        <!-- Card 2: Total Kriteria Penilaian -->
        <div class="lg:col-span-2 rounded-2xl bg-surface-container-lowest p-space-lg flex flex-col justify-between shadow-sm border border-outline-variant/10 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between">
                <div class="w-10 h-10 rounded-xl bg-primary-fixed/40 flex items-center justify-center text-primary">
                    <span class="material-symbols-outlined text-[22px]">tune</span>
                </div>
                <span class="px-2 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed font-label-sm text-label-sm font-semibold">
                    100%
                </span>
            </div>
            <div class="mt-space-md">
                <p class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Kriteria Bobot</p>
                <div class="font-numeric-metric text-numeric-metric text-on-surface mt-0.5 tracking-tight"><?php echo e($metrics['total_kriteria']); ?> Kriteria</div>
                <p class="font-body-sm text-body-sm text-on-surface-variant mt-1 truncate">Pembobotan metode AHP</p>
            </div>
        </div>

        <!-- Card 3: Model Penilaian Aktif -->
        <div class="lg:col-span-2 rounded-2xl bg-surface-container-lowest p-space-lg flex flex-col justify-between shadow-sm border border-outline-variant/10 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between">
                <div class="w-10 h-10 rounded-xl bg-secondary-fixed/50 flex items-center justify-center text-secondary">
                    <span class="material-symbols-outlined text-[22px]">account_tree</span>
                </div>
                <span class="px-2 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed font-label-sm text-label-sm font-semibold">
                    <?php echo e($metrics['metode']); ?>

                </span>
            </div>
            <div class="mt-space-md">
                <?php
                    $topCriterion = $ahp['kriterias']->sortByDesc(fn($k) => $ahp['weights'][$k->kode] ?? $k->bobot)->first();
                    $topWeight = $topCriterion ? ($ahp['weights'][$topCriterion->kode] ?? $topCriterion->bobot) : 0;
                ?>
                <p class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Kriteria Prioritas #1</p>
                <div class="font-numeric-metric text-numeric-metric text-secondary mt-0.5 tracking-tight text-xl truncate" title="<?php echo e($topCriterion->nama ?? '-'); ?>">
                    <?php echo e($topCriterion->kode ?? '-'); ?>: <?php echo e($topCriterion->nama ?? '-'); ?>

                </div>
                <p class="font-body-sm text-body-sm text-on-surface-variant mt-1 truncate">Bobot: <?php echo e(number_format($topWeight * 100, 2)); ?>%</p>
            </div>
        </div>

        <!-- Card 4: Rata-rata Skor Vi -->
        <div class="lg:col-span-2 rounded-2xl bg-surface-container-lowest p-space-lg flex flex-col justify-between shadow-sm border border-outline-variant/10 hover:shadow-md transition-shadow">
            <div class="flex items-start justify-between">
                <div class="w-10 h-10 rounded-xl bg-surface-container-high flex items-center justify-center text-primary">
                    <span class="material-symbols-outlined text-[22px]">military_tech</span>
                </div>
                <span class="px-2 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed font-label-sm text-label-sm font-semibold">
                    Pemenang
                </span>
            </div>
            <div class="mt-space-md">
                <p class="font-label-sm text-label-sm text-on-surface-variant uppercase tracking-wider">Alternatif Rekomendasi #1</p>
                <div class="font-numeric-metric text-numeric-metric text-primary mt-0.5 tracking-tight">
                    <?php echo e($ranked[0]['kode'] ?? '-'); ?> (<?php echo e(isset($ranked[0]) ? round($ranked[0]['vi'] * 100, 2) . '%' : '-'); ?>)
                </div>
                <p class="font-body-sm text-body-sm text-on-surface-variant mt-1 truncate">
                    <?php echo e($ranked[0]['alternatif']->nama ?? 'Belum ada alternatif'); ?>

                </p>
            </div>
        </div>

        <!-- Card 5: Quick Actions Panel -->
        <div class="lg:col-span-3 rounded-2xl bg-surface-container-lowest p-space-lg flex flex-col justify-between shadow-sm border border-outline-variant/10">
            <div class="flex items-center justify-between">
                <span class="font-headline-sm text-headline-sm text-on-surface">Aksi Cepat</span>
                <span class="text-primary font-label-sm text-xs font-semibold">Navigasi SPK</span>
            </div>
            <div class="grid grid-cols-3 gap-2.5 mt-space-md">
                <a href="<?php echo e(route('spk.alternatif')); ?>" class="flex flex-col items-center justify-center py-2.5 px-1.5 rounded-xl bg-primary-fixed/30 hover:bg-primary-fixed/50 transition-colors text-primary group">
                    <div class="w-8 h-8 rounded-lg bg-surface-container-lowest flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform mb-1">
                        <span class="material-symbols-outlined text-[18px]">table_chart</span>
                    </div>
                    <span class="font-label-sm text-[11px] font-semibold truncate">Matriks X</span>
                </a>
                <a href="<?php echo e(route('spk.kriteria')); ?>" class="flex flex-col items-center justify-center py-2.5 px-1.5 rounded-xl bg-secondary-fixed/30 hover:bg-secondary-fixed/50 transition-colors text-secondary group">
                    <div class="w-8 h-8 rounded-lg bg-surface-container-lowest flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform mb-1">
                        <span class="material-symbols-outlined text-[18px]">balance</span>
                    </div>
                    <span class="font-label-sm text-[11px] font-semibold truncate">Bobot AHP</span>
                </a>
                <a href="<?php echo e(route('spk.keputusan')); ?>" class="flex flex-col items-center justify-center py-2.5 px-1.5 rounded-xl bg-surface-container hover:bg-surface-container-high transition-colors text-primary group">
                    <div class="w-8 h-8 rounded-lg bg-primary text-on-primary flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform mb-1">
                        <span class="material-symbols-outlined text-[18px]">military_tech</span>
                    </div>
                    <span class="font-label-sm text-[11px] font-semibold truncate">Keputusan</span>
                </a>
            </div>
        </div>
    </div>

    <!-- Main Analytics Section (3-Column Visual Layout) -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-stretch">
        <!-- Column 1: Smooth Spline Splendor Chart (5 cols) -->
        <div class="lg:col-span-5 rounded-2xl bg-surface-container-lowest p-space-lg shadow-sm border border-outline-variant/10 flex flex-col justify-between">
            <div>
                <div class="flex items-center justify-between mb-1">
                    <h2 class="font-headline-sm text-headline-sm text-on-surface">Distribusi Nilai Preferensi (Vi)</h2>
                    <div class="flex items-center gap-2">
                        <span class="inline-block w-2.5 h-2.5 rounded-full bg-primary"></span>
                        <span class="font-label-sm text-label-sm text-on-surface-variant">Skor <?php echo e($metrics['metode']); ?></span>
                    </div>
                </div>
                <p class="font-body-sm text-body-sm text-on-surface-variant">Perbandingan nilai Vi dari seluruh alternatif</p>
            </div>

            <!-- Bar Chart of 8 Alternatives -->
            <div class="mt-space-md w-full space-y-2.5">
                <?php $__currentLoopData = $ranked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="space-y-1">
                        <div class="flex justify-between items-center text-xs font-label-md">
                            <span class="font-semibold text-on-surface"><?php echo e($item['kode']); ?> - <?php echo e($item['alternatif']->nama); ?></span>
                            <span class="font-bold <?php echo e($item['rank'] == 1 ? 'text-primary' : 'text-on-surface-variant'); ?>"><?php echo e(number_format($item['vi'], 4)); ?> (<?php echo e($item['kelayakan']); ?>)</span>
                        </div>
                        <div class="w-full bg-surface-container-high rounded-full h-2.5 overflow-hidden">
                            <div class="<?php echo e($item['rank'] == 1 ? 'bg-primary' : ($item['rank'] <= 3 ? 'bg-secondary' : 'bg-surface-dim')); ?> h-full rounded-full transition-all duration-500" style="width: <?php echo e($item['vi'] * 100); ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="mt-space-sm pt-space-xs flex items-center justify-between text-on-surface-variant font-label-sm text-label-sm border-t border-outline-variant/10">
                <span>Rekomendasi Utama: <strong class="text-primary font-bold"><?php echo e($ranked[0]['kode'] ?? '-'); ?> (<?php echo e($ranked[0]['alternatif']->nama ?? '-'); ?>)</strong></span>
                <span class="text-on-surface-variant">V = <?php echo e(isset($ranked[0]) ? number_format($ranked[0]['vi'], 4) : '0.0000'); ?></span>
            </div>
        </div>

        <!-- Column 2: Bobot Kriteria AHP Overview (3 cols) -->
        <div class="lg:col-span-3 rounded-2xl bg-surface-container-lowest p-space-lg shadow-sm border border-outline-variant/10 flex flex-col justify-between">
            <div>
                <h2 class="font-headline-sm text-headline-sm text-on-surface">Prioritas Kriteria AHP</h2>
                <p class="font-body-sm text-body-sm text-on-surface-variant">Hasil sintesis matriks perbandingan</p>
            </div>

            <!-- Kriteria Weights Breakdown -->
            <div class="my-space-md flex flex-col gap-2 max-h-[360px] overflow-y-auto pr-1">
                <?php
                    $sortedKriterias = $ahp['kriterias']->sortByDesc(fn($k) => $ahp['weights'][$k->kode] ?? $k->bobot);
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $sortedKriterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $w = $ahp['weights'][$k->kode] ?? $k->bobot;
                        $isTop = ($loop->first);
                    ?>
                    <div class="flex items-center justify-between p-2 rounded-xl <?php echo e($isTop ? 'bg-primary-fixed/30 border border-primary/20' : ($k->tipe == 'Cost' ? 'bg-tertiary-fixed/30 border border-tertiary/20' : 'bg-surface-container-low border border-outline-variant/10')); ?>">
                        <div class="min-w-0 pr-2">
                            <span class="font-label-sm font-bold <?php echo e($isTop ? 'text-primary' : ($k->tipe == 'Cost' ? 'text-tertiary' : 'text-on-surface')); ?> block truncate"><?php echo e($k->kode); ?>: <?php echo e($k->nama); ?></span>
                            <span class="text-[10px] text-on-surface-variant"><?php echo e($k->tipe); ?> (<?php echo e($k->satuan ?? '-'); ?>)</span>
                        </div>
                        <span class="font-headline-sm text-xs font-bold shrink-0 <?php echo e($isTop ? 'text-primary' : ($k->tipe == 'Cost' ? 'text-tertiary' : 'text-on-surface')); ?>"><?php echo e(number_format($w * 100, 2)); ?>%</span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-xs text-on-surface-variant text-center py-4">Belum ada kriteria.</div>
                <?php endif; ?>
            </div>

            <div class="pt-space-xs text-center border-t border-outline-variant/10">
                <span class="font-label-sm text-label-sm text-primary font-bold">Total Akumulasi: <?php echo e(number_format(array_sum($ahp['weights']) * 100, 1)); ?>%</span>
            </div>
        </div>

        <!-- Column 3: Top Ranked Alternatives List (4 cols) -->
        <div class="lg:col-span-4 rounded-2xl bg-surface-container-lowest p-space-lg shadow-sm border border-outline-variant/10 flex flex-col justify-between">
            <div>
                <div class="flex items-center justify-between mb-1">
                    <h2 class="font-headline-sm text-headline-sm text-on-surface">Peringkat Teratas (Top 5)</h2>
                    <a href="<?php echo e(route('spk.keputusan')); ?>" class="text-primary hover:text-primary-container font-label-sm text-label-sm font-semibold flex items-center gap-0.5">
                        <span>Lihat Semua</span>
                        <span class="material-symbols-outlined text-[16px]">arrow_forward</span>
                    </a>
                </div>
                <p class="font-body-sm text-body-sm text-on-surface-variant">Hasil kalkulasi skor preferensi <?php echo e($metrics['metode']); ?> (Vi)</p>
            </div>

            <!-- Ranked List Items -->
            <div class="flex flex-col gap-space-sm my-space-md">
                <?php $__currentLoopData = $topKandidat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kandidat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between p-2.5 rounded-xl hover:bg-surface-container-low transition-colors group <?php echo e($kandidat['rank'] == 1 ? 'bg-primary-fixed/20 border border-primary/20' : ''); ?>">
                        <div class="flex items-center gap-space-sm min-w-0">
                            <div class="w-9 h-9 rounded-xl <?php echo e($kandidat['rank'] == 1 ? 'bg-primary text-on-primary shadow-sm' : ($kandidat['rank'] == 2 ? 'bg-secondary text-on-secondary' : ($kandidat['rank'] == 3 ? 'bg-tertiary text-on-tertiary' : 'bg-surface-container text-on-surface-variant'))); ?> flex items-center justify-center font-bold text-label-md shrink-0">
                                #<?php echo e($kandidat['rank']); ?>

                            </div>
                            <div class="min-w-0">
                                <h3 class="font-label-md text-label-md text-on-surface truncate group-hover:text-primary transition-colors font-semibold">
                                    <?php echo e($kandidat['kode']); ?> (<?php echo e($kandidat['alternatif']->nama); ?>)
                                </h3>
                                <?php if(isset($kandidat['d_plus'], $kandidat['d_minus'])): ?>
                                    <span class="font-body-sm text-[11px] text-on-surface-variant">D+: <?php echo e(number_format($kandidat['d_plus'], 4)); ?> &bull; D-: <?php echo e(number_format($kandidat['d_minus'], 4)); ?></span>
                                <?php elseif(isset($kandidat['vector_s'])): ?>
                                    <span class="font-body-sm text-[11px] text-on-surface-variant">Vektor S: <?php echo e(number_format($kandidat['vector_s'], 4)); ?></span>
                                <?php else: ?>
                                    <span class="font-body-sm text-[11px] text-on-surface-variant">Skor Normalisasi Terbobot</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="text-right shrink-0 ml-2">
                            <div class="font-headline-sm text-sm text-on-surface font-bold"><?php echo e(number_format($kandidat['vi'], 4)); ?></div>
                            <span class="inline-block px-2 py-0.5 rounded-full <?php echo e($kandidat['rank'] == 1 ? 'bg-primary text-on-primary' : 'bg-primary-fixed text-on-primary-fixed'); ?> font-label-sm text-[10px] font-semibold">
                                <?php echo e($kandidat['status']); ?>

                            </span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <a href="<?php echo e(route('spk.keputusan')); ?>" class="w-full py-2.5 rounded-xl bg-surface-container text-on-surface hover:bg-surface-container-high transition-colors font-label-md text-label-md flex items-center justify-center gap-2">
                <span class="material-symbols-outlined text-[18px]">military_tech</span>
                <span>Buka Detail Keputusan Final</span>
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\SPK\resources\views/spk/dashboard.blade.php ENDPATH**/ ?>